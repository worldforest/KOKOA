-- MariaDB dump 10.17  Distrib 10.4.3-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: kokoa
-- ------------------------------------------------------
-- Server version	10.1.47-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `writenote`
--

DROP TABLE IF EXISTS `writenote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `writenote` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `subtitleid` int(11) DEFAULT NULL,
  `videoid` int(11) DEFAULT NULL,
  `engsubtitleid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_write_user_note_id` (`userid`),
  KEY `fk_write_video_note_id` (`videoid`),
  KEY `fk_write_subtitle_note_id` (`subtitleid`),
  CONSTRAINT `fk_write_subtitle_note_id` FOREIGN KEY (`subtitleid`) REFERENCES `subtitles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_write_user_note_id` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_write_video_note_id` FOREIGN KEY (`videoid`) REFERENCES `video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `writenote`
--

LOCK TABLES `writenote` WRITE;
/*!40000 ALTER TABLE `writenote` DISABLE KEYS */;
INSERT INTO `writenote` VALUES (6,614,14245,32,13944),(23,8,2185,3,1761),(25,1,9629,19,9574),(27,1,5695,11,5465),(75,6,9630,19,9575),(299,1,9327,18,9080),(445,8,5696,11,5466),(453,8,9629,19,9574),(528,8,27717,52,27535),(545,529,26948,51,26366),(604,594,9327,18,9080),(605,529,9948,22,9879),(618,614,587,1,1);
/*!40000 ALTER TABLE `writenote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-17 13:44:51
