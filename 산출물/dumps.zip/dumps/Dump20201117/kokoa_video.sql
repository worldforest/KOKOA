-- MariaDB dump 10.17  Distrib 10.4.3-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: kokoa
-- ------------------------------------------------------
-- Server version	10.1.47-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_video_id` (`groupid`),
  CONSTRAINT `fk_video_id` FOREIGN KEY (`groupid`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (1,1,'[MMTG EP.138] I went to Wooyoung\'s house instead of Junho\'s house and listened to 2PM Beast Dol\'s explanation','mLx7D98zP_A'),(3,2,'Shindong Gayo - Apink of Dumhdurum','WiUX2s4cEKA'),(9,3,'[MMTG EP.109] Naeun, do you want to act? April who just laughs at the provocation of a trainee who is a yob','8jpJgAiHdJE'),(10,3,'Shindong Gayo APRIL of \'LALALILALA\'','dXjwEtNHs4M'),(11,3,'April answered questions from fans! Answering Vending Machine Q&A Machine','UNPr1jkpXrU'),(12,3,'K-pop idols HAVE DONE IT AGAIN, Innocent yet Chaotic (ft. APRIL) _ LALALILALA _ Question Parade','BxCuLHs0NwU'),(13,3,'What the hell happened in 1999! Yeri X Naeun X Doyeon Nuclear Inssa Friends [EP.10-1]','GWCcPQElNjc'),(14,3,'Yeri\'s business drawing a big picture with 99 cone chemistry [EP.10-2]','c0t483T0uRE'),(15,3,'Yeri Naeun Doyeon, this combination is crazy [Highlight 2 Naeun Doyeon]','oO3_rFpg7Tw'),(16,3,'Yeri makes a hot debut as a stage stylist for Naeun\'s comeback [EP.11-2]','v-Sj1UXo3Xw'),(17,4,'[Knowingbros] Blackpink\'s world class entertainment performances collection.zip','wcA2x_XumuM'),(18,4,'[Runningman] Drive Big nose to a corner','z3_M-FUVaS8'),(19,4,'Jisoo reveals \'Dalgom\', a dog full of charm with a broadcast constitution! @Horizontal channel EP06','dJVPuv263FE'),(20,4,'[Knowingbros EP.251] Je t\'aime, French class of Teacher JENNIE who is dreaming of becoming a French master (ft.LISA)','Iewme5r9OaQ'),(21,4,'[Knowingbros EP.251] Lisa\'s pride for the style she\'s been keeping since she was in elementary school','PrwoB3EPTJ4'),(22,4,'[Knowingbros EP.251] Animal Lover JENNIE\'s Childhood Dream \'Panda Breeder\' (ft. Capybara)','__YO-svX1Dk'),(23,4,'[Knowingbros EP.251] The reason why the ROS? family held [Family Conference] every day (ft. singing practice)','V-B1_OgtaYw'),(24,4,'Black Pink\'s song \'Secret\', born with JISOO\'s wits','BGkhtR40PWE'),(25,4,'“No.” JISOO cuts Kim young chul\'s sincere recruitment like a knife','pGVKb6OSnhI'),(26,5,'BTS comeback commemoration! Dance special video','d_iQ2m72Vk0'),(30,6,'[SM Special] Maknae Minseok vs. Hyung minseok, this video will tell you the answer.','xhVu_E_mCy0'),(31,6,'Look at our Kyungsoo, who is good at all^^ EXO D.O.','F79kJi8N4eI'),(32,7,'[Knowingbros] Girls\' Generation responding to KIM HEE CHUL','uRnqxR4aKd8'),(33,8,'[MMTG EP.132] Lying down in bed wearing street dress _Possible vs Impossible, GFriend and Jaejae are just different tastes goosebumps;;','k9BoDgN6Jek'),(34,8,'[MMTG EP.133] GFriend 2020ver Best Friend Note','nAjS-qnItF0'),(37,9,'IU \"I will be sent to hell road \"pledge of anger @flowers nolyipae EP.14','mmURD9hDjSY'),(38,9,'\"Crunchy\" IU, bite to eat kimchi and \'jogon jogon representation\' @once pomnage EP.1','AEKbN7fax0Q'),(39,9,'Cute little drunk IU@ pomnage eat EP.2','H4Sbv3rFqm8'),(41,10,'[MMTG EP.115] The inverse fan signing event of monstaX, Jaejae\'s fan;; Really FANTASIA','Y_Sgp-bcR_s'),(42,10,'[MMTG EP.116] Really ripped_ MONSTA X ripped the atmosphere, ripped legs, ripped everything','Y_Sgp-bcR_s'),(44,10,'Why doesn\'t this video end.. JOOHONEY, the founder of kukukaka looks really crazy.. I mean the charm is…','m_TqvPU2Iwc'),(45,10,'MONSTA X, who suddenly lost her heart while eating, because of the members @Dingo School EP 06','ynNr1XqX9h8'),(46,10,'When I said to introduce yourself, MONSTA X took place in the diss war @Dingo School EP 02','Y5SkUSea2L8'),(47,11,'[MMTG EP.71] Entered SM! Go to SM basement practice room where 300 trainees are hiding','xJYBANCAfhk'),(48,11,'[MMTG EP.102] Who is NCT_ These are great people;; NCT 127 brought a ripped over to Jaejae\'s first fan affair ','yHXa9Sz3_6Y'),(51,12,'[MMTG EP.108] Oh My Girl Legend\'s entertainment may be Moondeok _ I was a little fluttered','Wl_bBKOY9hE'),(52,13,'From the campground gourmet meal mukbang to the heart of the two','Q0kGEu8ub9g'),(53,13,'[MMTG EP.130] Red Velvet-Irene&Seulgi with Jaejae tried to match with various K-superstitions...(feat. Charlie Charlie)','iUm9nERTP7Q'),(54,13,'[MMTG EP.131] Just staring at him kills him _ Seulgi and Jaejae, who were surprised by a single word of Irene','tP7S34Cgnr0'),(55,13,'[EN] 아이린, 슬기의 뽀뽀세례에 행복한 예리 [하이라이트1 레드벨벳편]','_rgOFnpQxJ4'),(56,13,'[EN] MC 뚜뚜 주최! 아이린X슬기와 아슬한 젠가 놀이 [EP.8-1]','VvWD3rgKy4U'),(57,13,'[EN] 진행 몬스터 예리 아이린X슬기에게 막내온탑 빨간맛 선물 (feat. 조이) [EP.7-2]','P879uMisykc'),(58,13,'[EN] 모였다 하면 꺄르륵 레드벨벳 연습실 리얼캠(feat. 아이린, 슬기, 조이) [주간예림이 모음집 1탄]','xk2_UFIwI-8'),(59,13,'[EN] 치키차카 뚜뚜초코초 손 소독제 만들기 \'예리한 방역\' [EP.17-1]','0eqG4HnL8dQ'),(60,13,'알고보니 사상최초_! 예리 추천 예리한 식사 스타뚜 with 열음 언니 (주간예림이 feat. 태연) [EP.14-2]','z85kq0oM308'),(61,13,'[EN] 예리 먹칠 주의 토크 빌런 \'예리\' 오픈 기념 베타 테스트중 [EP.1-2]','nhbOzOzxRWc'),(62,14,'[MMTG EP.123] 어머 얘 좀 봐라 얘 무슨 일이 있었길래 초면에 말 놨대 어_ 매사에 진심인 세븐틴과의 즐거운 시간 (설참♡)','H-WQL-XV8Ak'),(63,14,'[GOING SEVENTEEN 2020] EP.23 드립 _ 세븐틴 갓 탤런트 #1 (Ad-lib _ Seventeen\'s got Talent #1)','vVAPe9DZxB4'),(64,14,'[GOING SEVENTEEN 2020] EP.24 드립 _ 세븐틴 갓 탤런트 #2 (Ad-lib _ Seventeen\'s got Talent #2)','bVpPO8giupY'),(65,14,'(ENG SUB)[EP01] 세븐틴 출첵라이브 1부 (SEVENTEEN Inkigayo Check-in LIVE)_매력발산HOT6 & 순발력대결','Iny4unt0pRE'),(66,14,'(ENG SUB)[EP02] 세븐틴 출첵라이브 2부 (SEVENTEEN Inkigayo Check-in LIVE)_ 순발력대결&릴레이 먹방','AtEqeeato5c'),(67,15,'Ep 10. 함께 _ Analog Trip (아날로그 트립)','PZGoizlB2aM'),(69,15,'Ep 12. 재회 _ Analog Trip (아날로그 트립)','MJaM25zuddQ'),(70,15,'Ep 13. 동방신기와 슈퍼주니어의 ‘아날로그 트립’ 뒤풀이 라이브','HllpEnuVczc'),(71,15,'[HOT CLIPS] [MY LITTLE OLD BOY] _Be careful!_ HEECHUL White House (ENG SUB)','xd8BNfrrUMY'),(72,15,'Ep 1. 아날로그 트립 여행의 실체 _ Analog Trip (아날로그 트립)','ioWAoEVYaP0'),(73,15,'Ep 2. 본격적인 \'아날로그 여행\' 시작 _ Analog Trip (아날로그 트립)','uco4Eymlk1M'),(74,15,'Ep 3. 한걸음 한걸음 거대함과 신비함을 _ Analog Trip (아날로그 트립)','15Q3l-Aw5wM'),(75,15,'Ep 4. 강렬한 오프로드의 맛 _ Analog Trip (아날로그 트립)','oll5TR7mrHQ'),(76,15,'Ep 5. 진솔한 대화 _ Analog Trip (아날로그 트립)','PcBgWbaAkpE'),(77,15,'Ep 6. 이곳은 천국인가 지옥인가_ _ Analog Trip (아날로그 트립)','KdHUKXpQhb4'),(78,15,'Ep 7. 천국의 빛 _ Analog Trip (아날로그 트립)','NGGOROs8ugw'),(79,15,'Ep 8. 극복 _ Analog Trip (아날로그 트립)','zCvi8-sBcpk'),(80,15,'Ep 9. 새로운 도전의 시작 _ Analog Trip (아날로그 트립)','qg14nAR5_pM'),(81,16,'(ENG SUB)[MMTG EP.65] 역대급 숨듣명 맛집! 신토불이 아이돌 ☆티아라 T-ARA★ 드디어 영접 (feat. 광수 사장)','gQ0PVNo_hu8'),(82,16,'[MMTG EP.91] 티아라 지연 MMTG 왔다가 기절초풍한 사연 또르르˚˚˚｀˙。눈물ol 흘ㄹJ간ㄷL˚˚˚｀˙。','5hDLF4ESnrs'),(85,17,'(ENG SUB)[EP02] 트와이스 출첵라이브 2부 (TWICE Inkigayo Check-in LIVE)_몸으로 말해요&순발력대결&먹방&실시간 Q&A','dvHq3NaC0K0'),(86,17,'[6시내고향] 트와이스가..여기서 춤을 춰_.. ♡ _ TWICE, what happened in the farm village. #once #moreandmore','TU9GnAyzawM'),(87,17,'[EN] 이 우정 짜릿해! 최고야! 레드벨벳 예리 & 트와이스 나연 [EP.2-1]','5-40gjivVxI'),(88,17,'[HOT CLIPS] [RUNNINGMAN]TWICE new song performance!(ENG SUB)','DYNCILvW0ig'),(89,17,'[RUNNINGMAN THE LEGEND] The RACE with TWICE on Busan!! (ENG SUB)','6Xdo-o2QSxI'),(90,17,'[선공개] 불량 트와이스(TWICE) 의 형님 제압! 쯔위(Tzuyu), _형님들 쉿!_ - 아는 형님(Knowing bros) 27회','jANzH5JioTI'),(92,17,'6시내고향 × 트와이스 (1부) 트둥이의 more내기 ♡ #moreandmore #twice #once #오만보기','DdUYiULhRSQ'),(93,17,'6시내고향x트와이스 (2부) 할머니 생각나요ㅠㅠ.._ TWICE !! Go to the countryside!! #twice #once #moreandmore #오만보기','SxfHotqNHMU'),(94,18,'[MMTG EP.114] 요즘 아이돌(투모로우바이투게더) 스토리텔링 수준ㄷㄷ;; CAN\'T YOU SEE ME_','tO-DEhq2sjI'),(96,18,'ENG SUB 신동가요 \'세계가 불타버린 밤, 우린...\' 투모로우바이투게더 _ Shindong Gayo TXT of \'Can\'t You See Me_\'','IcWkacYDawE'),(97,18,'(ENG SUB)[EP01] TOMORROW X TOGETHER 출첵라이브 1부 (TXT Inkigayo Check-in LIVE Ep.1) #매력발산HOT6 #몸으로말해요','DfXasCySFVM'),(98,18,'(ENG SUB)[EP02] TOMORROW X TOGETHER 출첵라이브 2부 (TXT Inkigayo Check-in LIVE Ep.2) #순발력대결 #먹방','4r26LZuFnWU'),(99,19,'[MMTG EP.119] (ENG SUB) 우주소녀 설아는 재재를 보고 왜 주먹을 들었을까_ _ 설참♡','l5E5bYBDCag'),(100,19,'(ENG SUB)[EP02] 우주소녀 출첵라이브 2부 (WJSN Inkigayo Check-in LIVE Ep.2) #순발력대결 #치킨먹방 #CF대결','7zYxSPNKM1E'),(101,1,'[RUNNINGMAN THE LEGEND] 2PM and Running Man, Keep your shoes! (ENG SUB)','Pijxpz0T1CA'),(102,2,'[HOT CLIPS] [RUNNINGMAN] APINK-Dumhdurum&CHUNGHA -Stay Tonight','KMdyiMasjKA'),(103,6,'[RUNNINGMAN THE LEGEND] KWANGSOO & EXO D.O is KISSING...','ev4UZ6ksoV4'),(104,7,'[RUNNINGMAN THE LEGEND] SNSD and Running Man, Escape from the Game World!','N_y0bcp1yEI'),(105,7,'Open the Love House of  Hyo Yeon, where Incheon Bridge is clearly visible','8Dj55JX9x0U'),(106,9,'[IU TV] Interview Hotel deluna','aStTtxiKNkg'),(107,9,'Spot Interview_IU_Palette ','jxscsgTyGB4'),(108,5,'KBS News9 BTS Interview 4 ','-PMVYa87Ftg'),(109,5,'KBS News9 BTS Interview 3 ','-PMVYa87Ftg'),(110,5,'KBS News9 BTS Interview 2 ','-PMVYa87Ftg'),(111,5,'KBS News9 BTS Interview 1 ','-PMVYa87Ftg');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-17 13:44:55
