-- MariaDB dump 10.17  Distrib 10.4.3-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: kokoa
-- ------------------------------------------------------
-- Server version	10.1.47-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=615 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (594,'4beth68@gmail.com'),(83,'betrayers000@gmail.com'),(350,'biky406@gmail.com'),(517,'bu03101@gmail.com'),(546,'dbsehdgus0520@gmail.com'),(521,'drkim0830@gmail.com'),(198,'duseh73@gmail.com'),(561,'ho0703dj1@gmail.com'),(100,'hodduc04@gmail.com'),(614,'hwandong.joo@gmail.com'),(8,'hysp6812@gmail.com'),(322,'jy5031le@gmail.com'),(551,'kns961120@gmail.com'),(591,'kyung9468@gmail.com'),(1,'lim.s.jin22@gmail.com'),(369,'loveys1023@gmail.com'),(77,'pyoun6599@gmail.com'),(6,'seul6854ki@gmail.com'),(7,'seulowxx@gmail.com'),(334,'sjh5665@gmail.com'),(557,'sonata0226@gmail.com'),(536,'ssafy3dj1085@gmail.com'),(588,'ssafylab@gmail.com'),(580,'wjdals0471@gmail.com'),(529,'worldforest99@gmail.com'),(610,'yeeejinn2@gmail.com'),(462,'yongujo001@gmail.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-17 13:44:57
